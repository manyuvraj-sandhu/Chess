#include "bishop.h"
#include "board.h"
#include "cpu1.h"
#include <string>
#include "pos.h"
#include "game.h"

char gameLoop(Game* game);

void setupLoop(Game* game);

